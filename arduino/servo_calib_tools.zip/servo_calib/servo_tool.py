#!/usr/bin/env python3
"""
servo_tool.py — calibrate and drive 16 SG90 linear actuators on a PCA9685,
using the `servo_calib.ino` firmware. ONE script, ONE config file.

All positions live in a JSON config (default: servo_config.json):

    {
      "frequency_hz": 50,
      "servos": {
        "0": { "recessed": 900, "neutral": 1500, "extended": 2100 },   # microseconds
        ...
      }
    }

SUBCOMMANDS
    calibrate         interactive: jog each servo, tag rec/neu/ext, save.
    drive             interactive: move servos by NAME (e.g. "0 extended").
    drive <ch> <pos>  one-shot: move one channel to a named position, exit.

COMMON OPTIONS
    --port  /dev/cu.usbmodemXXXX   (auto-detected if omitted)
    --baud  115200
    --config servo_config.json

EXAMPLES
    python3 servo_tool.py calibrate
    python3 servo_tool.py drive
    python3 servo_tool.py drive 3 extended

NOTE ON HOLDING POSITION: opening the serial port resets the Uno (standard
Uno DTR auto-reset), which re-limps every channel. So a one-shot `drive`
necessarily drops all other servos for ~2 s before commanding the one you
asked for. To hold many servos simultaneously, use interactive `drive` and
keep the session open. The PCA9685 latches PWM in hardware, so positions
persist as long as the board is not reset and OE stays enabled.
"""

import argparse
import curses
import glob
import json
import locale
import os
import sys
import threading
import time

try:
    import serial  # pyserial
except ImportError:
    sys.exit("pyserial is required:  pip3 install pyserial")


# Values are servo pulse widths in MICROSECONDS (firmware uses writeMicroseconds).
SOFT_MIN = 500     # µs — typical SG90 ~0° end; below this it usually buzzes
SOFT_MAX = 2500    # µs — typical SG90 ~180° end; above this it slams the stop
HARD_MIN, HARD_MAX = 0, 3000
NEUTRAL_US = 1500  # center
JOG_START  = 2000  # µs — where calibration jog begins on an uncalibrated channel
                   # (empirically near these SG90s' live travel; 1500 was dead)

NUM_CHANNELS = 16
POSITION_KEYS = ("recessed", "neutral", "extended")
POS_ALIASES = {
    "rec": "recessed", "recessed": "recessed", "r": "recessed",
    "neu": "neutral", "neutral": "neutral", "n": "neutral",
    "ext": "extended", "extended": "extended", "x": "extended",
}
DEFAULT_CONFIG = "servo_config.json"


def autodetect_port():
    cands = (glob.glob("/dev/cu.usbmodem*") + glob.glob("/dev/cu.usbserial*")
             + glob.glob("/dev/ttyACM*") + glob.glob("/dev/ttyUSB*"))
    return cands[0] if cands else None


def load_config(path):
    cfg = {"frequency_hz": 50, "servos": {}}
    if os.path.exists(path):
        with open(path) as f:
            cfg.update(json.load(f))
        cfg.setdefault("servos", {})
    return cfg


def save_config(cfg, path):
    with open(path, "w") as f:
        json.dump(cfg, f, indent=2, sort_keys=True)
        f.write("\n")
    print(f"   ✓ saved {path}")


# --------------------------------------------------------------------------
class Link:
    """Serial link with a background reader that echoes board replies."""

    def __init__(self, port, baud, verbose=True):
        self.ser = serial.Serial(port, baud, timeout=0.2)
        self.verbose = verbose          # False = don't print board lines (TUI)
        self._stop = False
        self._last_val = {}
        self._lock = threading.Lock()
        threading.Thread(target=self._read_loop, daemon=True).start()

    def _read_loop(self):
        buf = b""
        while not self._stop:
            try:
                data = self.ser.read(256)
            except Exception:
                break
            if not data:
                continue
            buf += data
            while b"\n" in buf:
                line, buf = buf.split(b"\n", 1)
                text = line.decode(errors="replace").strip()
                if not text:
                    continue
                if text.startswith("VAL"):
                    p = text.split()
                    if len(p) == 3:
                        with self._lock:
                            self._last_val[int(p[1])] = int(p[2])
                if self.verbose:
                    print(f"   < {text}")

    def send(self, cmd):
        self.ser.write((cmd + "\n").encode())
        self.ser.flush()

    def get_count(self, ch, timeout=0.5):
        with self._lock:
            self._last_val.pop(ch, None)
        self.send(f"G {ch}")
        deadline = time.time() + timeout
        while time.time() < deadline:
            with self._lock:
                if ch in self._last_val:
                    return self._last_val[ch]
            time.sleep(0.02)
        return None

    def open_wait(self):
        """Ride out the auto-reset/bootloader, then enable outputs."""
        time.sleep(2.0)
        self.ser.reset_input_buffer()
        self.send("E")

    def close(self):
        self._stop = True
        time.sleep(0.25)
        try:
            self.ser.close()
        except Exception:
            pass


def clamp_warn(count):
    count = max(HARD_MIN, min(HARD_MAX, int(count)))
    if count < SOFT_MIN or count > SOFT_MAX:
        print(f"   ! {count} is outside the safe SG90 band "
              f"({SOFT_MIN}-{SOFT_MAX}); jog gently / use 'off' if it buzzes.")
    return count


# ===================== CALIBRATE — live keyboard TUI =====================
#
# No typing. Pick a servo, hold the arrow keys to jog it in real time, tap
# one key to capture each position. Everything is visible on one screen.
#
#   Left / Right   jog -10 / +10 us       ,  / .   jog -2 / +2 us (fine)
#   Up   / Down    jog +50 / -50 us       Tab/S-Tab  next / prev channel
#   r / n / e      tag Recessed/Neutral/Extended at the current count
#   1 / 2 / 3      go to saved rec / neu / ext
#   space          release current servo (limp — stops buzzing)
#   t              test: sweep current servo rec->neu->ext->neu
#   s              save config        q   save & quit

class CalTUI:
    def __init__(self, link, cfg, config_path):
        self.link = link
        self.cfg = cfg
        self.config_path = config_path
        self.ch = 0
        self.count = self._neutral_of(0)
        self.dirty = False
        self.msg = "Hold arrow keys to jog the selected servo. Tab switches servos."

    def _neutral_of(self, ch):
        return self.cfg["servos"].get(str(ch), {}).get("neutral", JOG_START)

    def _servo(self, ch):
        return self.cfg["servos"].get(str(ch), {})

    def _is_done(self, ch):
        s = self._servo(ch)
        return all(k in s for k in POSITION_KEYS)

    def move(self, count):
        count = max(HARD_MIN, min(HARD_MAX, int(count)))
        self.count = count
        self.link.send(f"P {self.ch} {count}")
        if count < SOFT_MIN or count > SOFT_MAX:
            self.msg = f"! {count} outside safe SG90 band {SOFT_MIN}-{SOFT_MAX} - ease off / press space"
        else:
            self.msg = f"ch {self.ch}  ->  {count}"

    def jog(self, delta):
        self.move(self.count + delta)

    def select(self, ch):
        self.ch = ch % NUM_CHANNELS
        self.count = self._neutral_of(self.ch)
        self.msg = f"channel {self.ch} selected ({self.count} us) - jog to move it"

    def tag(self, key):
        self._servo(self.ch)  # ensure dict path via setdefault below
        self.cfg["servos"].setdefault(str(self.ch), {})[key] = self.count
        self.dirty = True
        extra = ""
        s = self.cfg["servos"][str(self.ch)]
        if all(k in s for k in POSITION_KEYS):
            r, n, e = (s[k] for k in POSITION_KEYS)
            if not ((r <= n <= e) or (r >= n >= e)):
                extra = "  (note: rec/neu/ext not in order)"
        self.msg = f"captured ch {self.ch} {key} = {self.count}{extra}"

    def goto(self, key):
        s = self._servo(self.ch)
        if key in s:
            self.move(s[key])
        else:
            self.msg = f"ch {self.ch} has no {key} captured yet"

    def release(self):
        self.link.send(f"O {self.ch}")
        self.msg = f"ch {self.ch} released (limp)"

    def save(self):
        with open(self.config_path, "w") as f:
            json.dump(self.cfg, f, indent=2, sort_keys=True)
            f.write("\n")
        self.dirty = False
        self.msg = f"saved -> {self.config_path}"

    def test(self, stdscr):
        s = self._servo(self.ch)
        if not all(k in s for k in POSITION_KEYS):
            self.msg = "capture all three positions before testing"
            return
        for key in ("recessed", "neutral", "extended", "neutral"):
            self.move(s[key])
            self.msg = f"test: ch {self.ch} -> {key} ({s[key]})"
            self.draw(stdscr)
            curses.napms(700)

    # ---- drawing -----------------------------------------------------------
    def draw(self, stdscr):
        stdscr.erase()
        h, w = stdscr.getmaxyx()
        C = curses

        def put(y, x, text, attr=0):
            if 0 <= y < h and 0 <= x < w:
                try:
                    stdscr.addnstr(y, x, text, max(0, w - x - 1), attr)
                except C.error:
                    pass

        done = sum(1 for ch in range(NUM_CHANNELS) if self._is_done(ch))
        bold = C.A_BOLD
        cur_a = C.color_pair(1) | bold
        ok_a = C.color_pair(2)
        warn_a = C.color_pair(3)

        put(0, 1, "PCA9685 SERVO CALIBRATION", bold)
        put(0, max(28, w - 16), f"[{done}/{NUM_CHANNELS} done]", ok_a if done == NUM_CHANNELS else 0)
        unsaved = "   *UNSAVED*" if self.dirty else ""
        put(1, 1, f"config: {self.config_path}{unsaved}", warn_a if self.dirty else 0)

        # --- current channel panel ---
        s = self._servo(self.ch)
        put(3, 2, f">> CHANNEL {self.ch:>2}      {self.count:>4} us", cur_a)

        lo, hi, width = SOFT_MIN, SOFT_MAX, 44

        def posx(v):
            v = min(max(v, lo), hi)
            return int((v - lo) / (hi - lo) * (width - 1))

        track = list("." * width)
        for key, letter in (("recessed", "R"), ("neutral", "N"), ("extended", "E")):
            if key in s:
                track[posx(s[key])] = letter
        track[posx(self.count)] = "|"
        put(4, 4, str(lo))
        put(4, 8, "".join(track))
        put(4, 8 + width + 1, str(hi))

        def cell(key):
            return f"{key[:3]}={s.get(key, '----'):>4}" if key in s else f"{key[:3]}= ----"
        put(5, 8, "    ".join(cell(k) for k in POSITION_KEYS))

        # --- 16-channel table, two columns ---
        put(7, 2, "ch   rec   neu   ext", bold)
        put(7, 42, "ch   rec   neu   ext", bold)

        def fmt(i):
            si = self._servo(i)
            g = lambda k: (str(si[k]) if k in si else "--")
            return f"{i:>2}  {g('recessed'):>4}  {g('neutral'):>4}  {g('extended'):>4}"

        for i in range(8):
            for col, ch in ((2, i), (42, i + 8)):
                mark = ">" if ch == self.ch else " "
                done_mark = " *" if self._is_done(ch) else ""
                attr = cur_a if ch == self.ch else (ok_a if self._is_done(ch) else 0)
                put(8 + i, col, f"{mark}{fmt(ch)}{done_mark}", attr)

        # --- message + key legend ---
        put(h - 5, 1, self.msg[: w - 2],
            warn_a if self.msg.startswith("!") else ok_a)
        put(h - 3, 1, "Left/Right +/-10us  Up/Down +/-50us  , . +/-2us  r n e: tag  1 2 3: goto", 0)
        put(h - 2, 1, "Tab/Shift-Tab: channel    space: release    t: test    s: save    q: quit", 0)
        stdscr.refresh()


def _cal_main(stdscr, link, cfg, config_path):
    curses.curs_set(0)
    if curses.has_colors():
        curses.start_color()
        curses.use_default_colors()
        curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_CYAN)   # current
        curses.init_pair(2, curses.COLOR_GREEN, -1)                  # done
        curses.init_pair(3, curses.COLOR_YELLOW, -1)                 # warn
    stdscr.keypad(True)
    tui = CalTUI(link, cfg, config_path)

    actions = {
        curses.KEY_RIGHT: lambda: tui.jog(+10),
        curses.KEY_LEFT:  lambda: tui.jog(-10),
        curses.KEY_UP:    lambda: tui.jog(+50),
        curses.KEY_DOWN:  lambda: tui.jog(-50),
        ord('.'): lambda: tui.jog(+2),
        ord(','): lambda: tui.jog(-2),
        ord('r'): lambda: tui.tag("recessed"),
        ord('n'): lambda: tui.tag("neutral"),
        ord('e'): lambda: tui.tag("extended"),
        ord('1'): lambda: tui.goto("recessed"),
        ord('2'): lambda: tui.goto("neutral"),
        ord('3'): lambda: tui.goto("extended"),
        ord(' '): tui.release,
        9:        lambda: tui.select(tui.ch + 1),   # Tab
        curses.KEY_BTAB: lambda: tui.select(tui.ch - 1),
        ord('s'): tui.save,
    }

    while True:
        tui.draw(stdscr)
        k = stdscr.getch()
        if k in (ord('q'), ord('Q')):
            if tui.dirty:
                tui.save()
            return
        if k in (ord('t'), ord('T')):
            tui.test(stdscr)
        elif k in actions:
            actions[k]()


def run_calibrate(link, cfg, config_path):
    locale.setlocale(locale.LC_ALL, "")
    link.verbose = False                 # keep board chatter off the TUI
    try:
        curses.wrapper(_cal_main, link, cfg, config_path)
    except curses.error as ex:
        print(f"TUI failed ({ex}). Try a larger terminal window.")
    print(f"Config: {os.path.abspath(config_path)}")


# ================================ DRIVE ==================================
def move_named(link, cfg, ch, pos_key):
    s = cfg["servos"].get(str(ch))
    if not s:
        print(f"   ! channel {ch} not in config"); return False
    if pos_key not in s:
        print(f"   ! channel {ch} has no '{pos_key}' saved"); return False
    count = clamp_warn(s[pos_key])
    link.send(f"P {ch} {count}")
    print(f"   → ch {ch} {pos_key} ({count})")
    return True


def parse_assignments(items, cfg):
    """Parse 'ch:pos' pairs (e.g. '12:extended 13:neu') -> [(ch, pos_key), ...].
    Validates channel is in config and the named position is saved."""
    out = []
    for item in items:
        if ":" not in item:
            raise ValueError(f"'{item}' must be CH:POSITION, e.g. 12:extended")
        ch_s, pos_s = item.split(":", 1)
        ch = int(ch_s)
        pos = pos_s.lower()
        if pos not in POS_ALIASES:
            raise ValueError(f"'{pos_s}' must be one of {list(POS_ALIASES)}")
        out.append((ch, POS_ALIASES[pos]))
    return out


def run_park(link, cfg, assignments, settle, interval):
    """Drive each servo to its named position, release power (limp), then
    periodically re-assert and release again. Friction holds the light load
    between refreshes; nothing is ever left energized or stalled.
    interval <= 0 means: park once and exit (servos left released)."""
    def assert_and_release():
        for ch, pos_key in assignments:
            if move_named(link, cfg, ch, pos_key):
                time.sleep(0.05)
        time.sleep(settle)            # let them arrive before cutting power
        for ch, _ in assignments:
            link.send(f"O {ch}")
        print(f"   released {len(assignments)} servo(s) (limp)")

    assert_and_release()
    if interval <= 0:
        return
    print(f"Holding: re-asserting every {interval:g}s. Ctrl-C to stop.")
    try:
        while True:
            time.sleep(interval)
            assert_and_release()
    except KeyboardInterrupt:
        print("\nStopped (servos left released).")


DRIVE_HELP = """\
   DRIVE COMMANDS  (positions: recessed|neutral|extended, or rec|neu|ext)
     <ch> <pos>      move channel to a named position   e.g.  3 extended
     all <pos>       move every configured channel to <pos>
     off <ch>        release a channel (limp)
     e / d / X       enable / disable / all-off
     list            show configured channels & positions
     help / q        help / quit
"""


def run_drive(link, cfg):
    if not cfg["servos"]:
        print("   ! config has no servos — run 'calibrate' first.")
    print(DRIVE_HELP)
    while True:
        try:
            raw = input("[drive] > ").strip()
        except EOFError:
            raw = "q"
        if not raw:
            continue
        p = raw.lower().split()
        cmd = p[0]
        if cmd.isdigit() and len(p) == 2 and p[1] in POS_ALIASES:
            move_named(link, cfg, int(cmd), POS_ALIASES[p[1]])
        elif cmd == "all" and len(p) == 2 and p[1] in POS_ALIASES:
            for ch_s in sorted(cfg["servos"], key=int):
                move_named(link, cfg, int(ch_s), POS_ALIASES[p[1]])
                time.sleep(0.05)
        elif cmd == "off" and len(p) == 2 and p[1].isdigit():
            link.send(f"O {int(p[1])}"); print(f"   ch {p[1]} released")
        elif cmd == "e":
            link.send("E")
        elif cmd == "d":
            link.send("D")
        elif cmd == "x":
            link.send("X")
        elif cmd == "list":
            for ch_s in sorted(cfg["servos"], key=int):
                s = cfg["servos"][ch_s]
                print(f"   ch {ch_s}: " + "  ".join(f"{k[:3]}={s.get(k, '—')}"
                                                    for k in POSITION_KEYS))
        elif cmd in ("help", "?"):
            print(DRIVE_HELP)
        elif cmd in ("quit", "q", "exit"):
            return
        else:
            print("   ? unknown — type 'help'")


# =============================== SWEEP ===================================
def run_sweep(link, ch, lo, hi, period):
    """Continuously sweep one channel between lo..hi microseconds until Ctrl-C.
    A clean way to confirm a single servo moves smoothly end-to-end."""
    lo = max(HARD_MIN, min(HARD_MAX, lo))
    hi = max(HARD_MIN, min(HARD_MAX, hi))
    if lo > hi:
        lo, hi = hi, lo
    steps = 40
    dwell = max(0.01, period / (2 * steps))
    print(f"Sweeping channel {ch} between {lo} and {hi} "
          f"({period:.1f}s/cycle). Watch that one servo. Ctrl-C to stop.")
    try:
        while True:
            for i in range(steps + 1):                  # lo -> hi
                link.send(f"P {ch} {int(lo + (hi - lo) * i / steps)}")
                time.sleep(dwell)
            for i in range(steps + 1):                  # hi -> lo
                link.send(f"P {ch} {int(hi - (hi - lo) * i / steps)}")
                time.sleep(dwell)
    except KeyboardInterrupt:
        print("\nStopped.")


def parse_channels(spec):
    """Parse a channel spec like 'all', '12-15', '0,3,5', '12-15,2' -> sorted list."""
    if spec is None or spec.lower() == "all":
        return list(range(NUM_CHANNELS))
    out = set()
    for part in spec.split(","):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-", 1)
            for ch in range(int(a), int(b) + 1):
                out.add(ch)
        elif part:
            out.add(int(part))
    chans = sorted(c for c in out if 0 <= c < NUM_CHANNELS)
    if not chans:
        raise ValueError(f"no valid channels in '{spec}'")
    return chans


def _sweep_cycle(link, channels, lo, hi, period):
    """One back-and-forth sweep of the given channels (together)."""
    steps = 30
    dwell = max(0.01, period / (2 * steps))

    def send(us):
        for ch in channels:
            link.send(f"P {ch} {us}")
            time.sleep(0.003)          # pace so we don't overflow the Uno's RX buffer

    for i in range(steps + 1):                          # lo -> hi
        send(int(lo + (hi - lo) * i / steps))
        time.sleep(dwell)
    for i in range(steps + 1):                          # hi -> lo
        send(int(hi - (hi - lo) * i / steps))
        time.sleep(dwell)


def run_sweep_all(link, channels, lo, hi, period, each):
    """Sweep the given channels through their full range until Ctrl-C.

    each=False: all listed channels move together (load test).
    each=True : one channel at a time, announced, so you can see exactly
                which servos respond and which don't (per-channel diagnostic).
    """
    lo = max(HARD_MIN, min(HARD_MAX, lo))
    hi = max(HARD_MIN, min(HARD_MAX, hi))
    if lo > hi:
        lo, hi = hi, lo

    label = ",".join(str(c) for c in channels)
    try:
        if each:
            print(f"Per-channel sweep of channels [{label}] between {lo}-{hi} us. "
                  f"Watch which servo moves as each is announced. Ctrl-C to stop.")
            while True:
                for ch in channels:
                    print(f"  >> testing channel {ch} ...", flush=True)
                    _sweep_cycle(link, [ch], lo, hi, period)
                    link.send(f"O {ch}")                # release so it's obvious when the next starts
                    time.sleep(0.3)
        else:
            print(f"Sweeping channels [{label}] together between {lo}-{hi} us "
                  f"({period:.1f}s/cycle). Ctrl-C to stop.")
            while True:
                _sweep_cycle(link, channels, lo, hi, period)
    except KeyboardInterrupt:
        print("\nStopped.")


# ================================ MAIN ===================================
def main():
    ap = argparse.ArgumentParser(description="PCA9685 servo calibrate/drive tool")
    ap.add_argument("--port", default=None)
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--config", default=DEFAULT_CONFIG)
    sub = ap.add_subparsers(dest="mode", required=True)
    sub.add_parser("calibrate", help="interactive calibration")
    d = sub.add_parser("drive", help="drive servos by named position")
    d.add_argument("channel", nargs="?", type=int, help="one-shot: channel")
    d.add_argument("position", nargs="?", help="one-shot: rec/neu/ext")
    d.add_argument("--release", action="store_true",
                   help="after reaching the position, release the servo (limp)")
    pk = sub.add_parser("park", help="move servos to named positions, cut power, refresh periodically")
    pk.add_argument("assignments", nargs="+", metavar="CH:POS",
                    help="e.g. 12:extended 13:neutral 14:recessed")
    pk.add_argument("--settle", type=float, default=0.6,
                    help="seconds to wait for arrival before cutting power (default 0.6)")
    pk.add_argument("--interval", type=float, default=0.0,
                    help="re-assert every N seconds (0 = park once and exit; default 0)")
    sw = sub.add_parser("sweep", help="continuously sweep one channel (diagnostic)")
    sw.add_argument("channel", type=int, help="channel to sweep (0-15)")
    sw.add_argument("--lo", type=int, default=1000, help="low pulse width us (default 1000)")
    sw.add_argument("--hi", type=int, default=2000, help="high pulse width us (default 2000)")
    sw.add_argument("--period", type=float, default=2.0, help="seconds per full cycle")
    swa = sub.add_parser("sweepall", help="sweep channels through full range (diagnostic)")
    swa.add_argument("--channels", default="all",
                     help="channels to sweep: 'all', '12-15', '0,3,5' (default all)")
    swa.add_argument("--each", action="store_true",
                     help="sweep one channel at a time (announced) to diagnose which respond")
    swa.add_argument("--lo", type=int, default=SOFT_MIN, help=f"low us (default {SOFT_MIN})")
    swa.add_argument("--hi", type=int, default=SOFT_MAX, help=f"high us (default {SOFT_MAX})")
    swa.add_argument("--period", type=float, default=3.0, help="seconds per full cycle")
    args = ap.parse_args()

    cfg = load_config(args.config)

    port = args.port or autodetect_port()
    if not port:
        sys.exit("No serial port found. Pass --port /dev/cu.usbmodemXXXX")

    print(f"Connecting to {port} @ {args.baud} …")
    link = Link(port, args.baud)
    link.open_wait()

    one_shot = (args.mode == "drive" and args.channel is not None
                and args.position is not None)
    try:
        if args.mode == "calibrate":
            run_calibrate(link, cfg, args.config)
        elif args.mode == "sweep":
            run_sweep(link, args.channel, args.lo, args.hi, args.period)
        elif args.mode == "park":
            run_park(link, cfg, parse_assignments(args.assignments, cfg),
                     args.settle, args.interval)
        elif args.mode == "sweepall":
            run_sweep_all(link, parse_channels(args.channels), args.lo, args.hi,
                          args.period, args.each)
        elif one_shot:
            pos = args.position.lower()
            if pos not in POS_ALIASES:
                print(f"   ! position must be one of {list(POS_ALIASES)}")
            else:
                move_named(link, cfg, args.channel, POS_ALIASES[pos])
                time.sleep(0.5)   # let the move register before we close
                if args.release:
                    link.send(f"O {args.channel}")
                    print(f"   ch {args.channel} released (limp)")
        else:
            run_drive(link, cfg)
    finally:
        # Leave servos holding their last commanded position on exit.
        link.close()


if __name__ == "__main__":
    main()
