/*
 * servo_calib.ino
 *
 * Firmware for an Arduino Uno + Adafruit PCA9685 driving up to 16 SG90
 * servos (servo-actuated linear actuators needing RECESSED / NEUTRAL /
 * EXTENDED positions).
 *
 * "Dumb" executor: drives servo pulse widths in MICROSECONDS and acks
 * every command. ALL calibration data lives on the host (servo_tool.py +
 * the JSON config) — nothing is stored here.
 *
 * Wiring:
 *   PCA9685 SDA → A4, SCL → A5,  GND ↔ Uno GND (signal reference).
 *   PCA9685 OE  → GND  (outputs permanently enabled — no software control).
 *   PCA9685 VCC → 5 V (logic).
 *   PCA9685 V+  → dedicated 5–6 V servo supply via the SCREW TERMINAL, and
 *                 the supply's (–) MUST return to the screw-terminal GND so
 *                 amps of servo current do NOT flow back through the Arduino.
 *
 * Why microseconds (writeMicroseconds) instead of raw counts:
 *   The library converts µs → PWM count using the configured oscillator
 *   frequency and prescale, so a 1500 µs request stays 1500 µs regardless
 *   of the exact PWM frequency. We also call setOscillatorFrequency() before
 *   setPWMFreq() — without it the library assumes 25 MHz and the real rate
 *   drifts (~54 Hz). 27 MHz is Adafruit's empirical default; tune it if you
 *   ever scope the output and want exact timing (not needed for empirical
 *   calibration, where you just capture whatever µs gives the right travel).
 *
 * At boot, all 16 channels are driven to NEUTRAL_US so every servo centers
 * and HOLDS — a held (non-back-driveable) servo proves signal + power are
 * good; a limp servo is getting no signal.
 *
 * ---------------------------------------------------------------------
 * SERIAL PROTOCOL  (115200 baud, '\n'-terminated, case-insensitive)
 *
 *   P <ch> <us>   Set channel <ch> (0-15) pulse width in microseconds.
 *                   → "OK P <ch> <us>"
 *   O <ch>        Off: release channel (no pulse, servo limp). → "OK O <ch>"
 *   G <ch>        Get last µs written.  → "VAL <ch> <us>"  (-1 = off)
 *   X             All channels off.     → "OK X"
 *   E / D         Accepted no-ops (OE hardwired). → "OK E" / "OK D"
 *   ?             Print help.
 *   else          → "ERR <echo>"
 * ---------------------------------------------------------------------
 */

#include <Wire.h>
#include <Adafruit_PWMServoDriver.h>

Adafruit_PWMServoDriver pwm = Adafruit_PWMServoDriver(0x40);

static const uint8_t  NUM_CHANNELS = 16;
static const uint16_t NEUTRAL_US   = 1500;     // servo center
static const uint16_t US_MAX       = 3000;     // hard clamp (well under 20ms)
static const uint16_t OFF_SENTINEL = 0xFFFF;   // marks "channel is limp"

uint16_t curUs[NUM_CHANNELS];

char    lineBuf[48];
uint8_t lineLen = 0;

void channelOff(uint8_t ch) {
    if (ch >= NUM_CHANNELS) return;
    curUs[ch] = OFF_SENTINEL;
    pwm.setPWM(ch, 0, 4096);   // PCA9685 "full off" bit → no pulse
}

void channelSet(uint8_t ch, uint16_t us) {
    if (ch >= NUM_CHANNELS) return;
    if (us > US_MAX) us = US_MAX;
    curUs[ch] = us;
    pwm.writeMicroseconds(ch, us);
}

void printHelp() {
    Serial.println(F("PCA9685 firmware (microseconds). Commands (\\n-terminated):"));
    Serial.println(F("  P <ch> <us>  set pulse width in microseconds"));
    Serial.println(F("  O <ch>       channel off (limp)"));
    Serial.println(F("  G <ch>       get last us (VAL ...; -1 = off)"));
    Serial.println(F("  X            all channels off"));
    Serial.println(F("  E / D        no-ops (OE hardwired to GND)"));
    Serial.println(F("  ?            this help"));
}

void handleLine(char *line) {
    while (*line == ' ') line++;
    switch (*line) {
        case 'P': case 'p': {
            int ch, us;
            if (sscanf(line + 1, "%d %d", &ch, &us) == 2 &&
                ch >= 0 && ch < NUM_CHANNELS && us >= 0 && us <= US_MAX) {
                channelSet((uint8_t)ch, (uint16_t)us);
                Serial.print(F("OK P ")); Serial.print(ch);
                Serial.print(' ');        Serial.println(us);
            } else { Serial.print(F("ERR ")); Serial.println(line); }
            return;
        }
        case 'O': case 'o': {
            int ch;
            if (sscanf(line + 1, "%d", &ch) == 1 && ch >= 0 && ch < NUM_CHANNELS) {
                channelOff((uint8_t)ch);
                Serial.print(F("OK O ")); Serial.println(ch);
            } else { Serial.print(F("ERR ")); Serial.println(line); }
            return;
        }
        case 'G': case 'g': {
            int ch;
            if (sscanf(line + 1, "%d", &ch) == 1 && ch >= 0 && ch < NUM_CHANNELS) {
                long v = (curUs[ch] == OFF_SENTINEL) ? -1L : (long)curUs[ch];
                Serial.print(F("VAL ")); Serial.print(ch);
                Serial.print(' ');       Serial.println(v);
            } else { Serial.print(F("ERR ")); Serial.println(line); }
            return;
        }
        case 'X': case 'x':
            for (uint8_t i = 0; i < NUM_CHANNELS; i++) channelOff(i);
            Serial.println(F("OK X")); return;
        case 'E': case 'e': Serial.println(F("OK E")); return;  // no-op
        case 'D': case 'd': Serial.println(F("OK D")); return;  // no-op
        case '?': printHelp(); return;
        default: Serial.print(F("ERR ")); Serial.println(line); return;
    }
}

void setup() {
    Serial.begin(115200);

    pwm.begin();
    pwm.setOscillatorFrequency(27000000);   // before setPWMFreq for accuracy
    pwm.setPWMFreq(50);                      // 50 Hz hobby-servo rate

    // Center every channel so all servos hold. Stagger limits inrush.
    for (uint8_t i = 0; i < NUM_CHANNELS; i++) {
        channelSet(i, NEUTRAL_US);
        delay(8);
    }

    Serial.println(F("READY servo_calib (microseconds, all -> 1500us)"));
    printHelp();
}

void loop() {
    while (Serial.available() > 0) {
        char ch = (char)Serial.read();
        if (ch == '\n' || ch == '\r') {
            if (lineLen > 0) {
                lineBuf[lineLen] = '\0';
                handleLine(lineBuf);
                lineLen = 0;
            }
        } else if (lineLen < sizeof(lineBuf) - 1) {
            lineBuf[lineLen++] = ch;
        }
    }
}
